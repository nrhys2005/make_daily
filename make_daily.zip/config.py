#info

#공공데이터 OPEN API(특일정보) KEY
serviceKey = "공공데이터 OPEN API(특일정보) KEY" 

#ID
etoos_id = "Confluence ID"
etoos_pw = "Confluence PW"
